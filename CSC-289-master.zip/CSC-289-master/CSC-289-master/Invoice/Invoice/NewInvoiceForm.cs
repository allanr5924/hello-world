﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Invoice
{
    public partial class NewInvoiceForm : Form
    {
        public NewInvoiceForm()
        {
            InitializeComponent();
        }
    }
}
